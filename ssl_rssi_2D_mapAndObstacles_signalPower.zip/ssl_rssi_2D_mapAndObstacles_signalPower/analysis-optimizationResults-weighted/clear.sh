rm data_0sigma/*
rm data_4sigma/*
rm data_8sigma/*
rm data_12sigma/*
