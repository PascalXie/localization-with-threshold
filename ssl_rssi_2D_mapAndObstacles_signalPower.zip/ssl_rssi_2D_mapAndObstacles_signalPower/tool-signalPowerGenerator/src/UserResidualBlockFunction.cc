#include "UserResidualBlockFunction.hh"

//-------------------------
// Constructor
//-------------------------
UserResidualBlockFunction::UserResidualBlockFunction(string name)
:	name_(name)
{}

//-------------------------
// Destructor
//-------------------------
UserResidualBlockFunction::~UserResidualBlockFunction()
{}

//-------------------------
// Public
//-------------------------
