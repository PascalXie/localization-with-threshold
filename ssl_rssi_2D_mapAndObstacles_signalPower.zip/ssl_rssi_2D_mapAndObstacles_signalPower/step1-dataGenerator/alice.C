#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <random>

#include "UserCostFunction.hh"
#include "SteepestCostFunction.hh"
#include "NewtonsCostFunction.hh"

#include "UserResidualBlockFunction.hh"
#include "PolyResidualBlockFunction.hh"

#include "UserOptimizationManager.hh"
#include "SteepestOptimizationManager.hh"
#include "NewtonsOptimizationManager.hh"

#include "ToolNodesGenerator.hh"
#include "ToolMapGenerator.hh"
#include "ToolSignalPowerGenerator.hh"


using namespace std;

vector<double> Nxs_c, Nys_c;
vector<double> Nxs_a_1, Nys_a_1;
vector<double> Nxs_a_2, Nys_a_2;


void NodesGenerator();

int main()
{
	cout<<"Hello "<<endl;

	// step 1 : generate samples
	NodesGenerator();

	// step 2 :  generate observations
	ToolMapGenerator * map = new ToolMapGenerator("Map", "3D");

	for(int i=0;i<Nxs_c.size();i++)
	{
		map->SetSample(0.,Nxs_c[i],Nys_c[i]);
	}
	for(int i=0;i<Nxs_a_1.size();i++)
	{
		map->SetSample(0.,Nxs_a_1[i],Nys_a_1[i]);
	}
	for(int i=0;i<Nxs_a_2.size();i++)
	{
		map->SetSample(0.,Nxs_a_2[i],Nys_a_2[i]);
	}

	map->SetSigma(10);

	map->OutputSamples();

	return 1;
}

void NodesGenerator()
{
	vector<double> Nzs;

	// concrete
	ToolNodesGenerator * ng = new ToolNodesGenerator("ng_c", 100, 1, "2D");
	ng->SetBoundaryX(-50,50);
	ng->SetBoundaryY(-100,100);
	ng->Initialize();

	ng->GetAnchors(Nxs_c, Nys_c, Nzs);

	// air
	ToolNodesGenerator * nga = new ToolNodesGenerator("ng_a1", 50, 1, "2D");
	nga->SetBoundaryX(-100,-50);
	nga->SetBoundaryY(-100,100);
	nga->Initialize();

	nga->GetAnchors(Nxs_a_1, Nys_a_1, Nzs);


	// air2
	ToolNodesGenerator * nga2 = new ToolNodesGenerator("ng_a2", 50, 1, "2D");
	nga2->SetBoundaryX(50,100);
	nga2->SetBoundaryY(-100,100);
	nga2->Initialize();

	nga2->GetAnchors(Nxs_a_2, Nys_a_2, Nzs);


	/*
	// debug
	for(int i=0;i<Nxs_c.size();i++)
	{
		cout<<"Concrete ID "<<i<<", x "<<Nxs_c[i]<<", y "<<Nys_c[i]<<endl;
	}
	for(int i=0;i<Nxs_a_1.size();i++)
	{
		cout<<"Air ID "<<i<<", x "<<Nxs_a_1[i]<<", y "<<Nys_a_1[i]<<endl;
	}
	for(int i=0;i<Nxs_a_2.size();i++)
	{
		cout<<"Air ID "<<i<<", x "<<Nxs_a_2[i]<<", y "<<Nys_a_2[i]<<endl;
	}
	*/
}
